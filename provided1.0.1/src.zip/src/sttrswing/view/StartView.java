package sttrswing.view;

import sttrswing.controller.GameController;
import sttrswing.model.interfaces.GameModel;
import sttrswing.view.panels.EnterpriseStatus;
import sttrswing.view.panels.Options;
import sttrswing.view.panels.QuadrantNavigation;
import sttrswing.view.panels.QuadrantScan;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Objects;

/**
 * {@inheritDoc}
 */
public class StartView extends View {

    private static final String TITLE = "Welcome";
    private static final String WELCOME_PANEL_TITLE = "Welcome";
    private static final String WELCOME_LABEL_TEXT = "Star Trek";
    private static final String WELCOME_MESSAGE =
            "WELCOME CAPTAIN\nClick the Start button to begin your mission.";

    private JButton button;
    private JTextArea textArea;

    public StartView(GameModel game, GameController controller) {
        super(TITLE);

        GameModel gameModel = Objects.requireNonNull(game, "game");
        GameController gameController = Objects.requireNonNull(controller, "controller");

        this.setLayout(new GridLayout(2, 2, 10, 10));

        View welcomePanel = createWelcomePanel(gameModel, gameController);
        EnterpriseStatus enterpriseStatus = new EnterpriseStatus(gameModel);
        QuadrantScan quadrantScan = new QuadrantScan(gameModel);
        Options options = new Options(gameModel, gameController);

        this.add(welcomePanel);
        this.add(enterpriseStatus);
        this.add(quadrantScan);
        this.add(options);
    }

    public JButton getButton() {
        return this.button;
    }

    public JTextArea getText() {
        return this.textArea;
    }

    private View createWelcomePanel(GameModel game, GameController controller) {
        WelcomeView panel = new WelcomeView(WELCOME_PANEL_TITLE, game, controller);
        this.textArea = panel.getTextArea();
        this.button = panel.getButton();
        return panel;
    }

    private static class WelcomeView extends View {

        private final JButton button;
        private final JTextArea textArea;

        WelcomeView(String title, GameModel game, GameController controller) {
            super(title);
            this.setLayout(new BorderLayout());

            JLabel label = new JLabel(WELCOME_LABEL_TEXT, SwingConstants.CENTER);
            label.setFont(new Font("Monospaced", Font.BOLD, 24));
            label.setForeground(Pallete.GREENTERMINAL.color());
            this.add(label, BorderLayout.NORTH);

            this.textArea = new JTextArea();
            this.textArea.setEditable(false);
            this.textArea.setBackground(Pallete.BLACK.color());
            this.textArea.setForeground(Pallete.GREENPALE.color());
            this.textArea.setFont(new Font("Monospaced", Font.BOLD, 16));
            this.textArea.setLineWrap(true);
            this.textArea.setWrapStyleWord(true);
            this.textArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            this.textArea.setText(WELCOME_MESSAGE);
            this.add(this.textArea, BorderLayout.CENTER);

            this.button = this.buildButton("START",
                    e -> controller.setDefaultView(new QuadrantNavigation(game, controller)));
            this.button.setFocusPainted(false);
            this.add(this.button, BorderLayout.SOUTH);
        }

        JButton getButton() {
            return this.button;
        }

        JTextArea getTextArea() {
            return this.textArea;
        }
    }
}
